(function(){
  var h=document.head;
  function add(tag,attrs){var e=document.createElement(tag);for(var k in attrs)e.setAttribute(k,attrs[k]);h.appendChild(e)}
  add("link",{rel:"manifest",href:"manifest.json"});
  add("link",{rel:"apple-touch-icon",href:"icon-192.png"});
  add("meta",{name:"theme-color",content:"#000000"});
  add("meta",{name:"mobile-web-app-capable",content:"yes"});
  add("meta",{name:"apple-mobile-web-app-capable",content:"yes"});
  add("meta",{name:"apple-mobile-web-app-status-bar-style",content:"black-translucent"});
  add("meta",{name:"apple-mobile-web-app-title",content:"YouX"});
  if("serviceWorker" in navigator)addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){})});
})();

/* Автовход: если сессия сохранена, не показываем экран входа */
(function(){
  var has=false;
  try{for(var i=0;i<localStorage.length;i++){if(/^sb-.*-auth-token$/.test(localStorage.key(i)))has=true}}catch(e){}
  if(!has)return;
  var s=document.createElement("style");
  s.textContent="#app[data-v=auth] #m{visibility:hidden}";
  document.head.appendChild(s);
  var mo=new MutationObserver(function(){
    var a=document.getElementById("app");
    if(a&&a.dataset.v!=="auth")done();
  });
  function done(){if(s.parentNode)s.remove();mo.disconnect()}
  mo.observe(document.documentElement,{attributes:true,subtree:true,attributeFilter:["data-v"]});
  setTimeout(done,5000);
})();
